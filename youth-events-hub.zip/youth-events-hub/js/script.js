document.addEventListener("DOMContentLoaded", () => {
  // Search filter for events
  const searchInput = document.getElementById("eventSearch");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      const query = searchInput.value.toLowerCase();
      document.querySelectorAll(".event-card").forEach(card => {
        card.style.display = card.textContent.toLowerCase().includes(query) ? "block" : "none";
      });
    });
  }

  // Form validation for contact
  const form = document.getElementById("contactForm");
  if (form) {
    form.addEventListener("submit", e => {
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const message = document.getElementById("message").value.trim();
      if (!name || !email || !message) {
        e.preventDefault();
        alert("Please fill out all fields.");
      } else {
        alert("Message submitted successfully!");
      }
    });
  }
});
